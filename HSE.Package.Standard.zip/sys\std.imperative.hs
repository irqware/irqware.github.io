 //   standard directives imperative header
#compile (select= __.Host.Compiler) // Select compiler (By default is host )

//  Add a reference in the selected compiler 
#compile (build=ctor) {  
     __.Host.Processor.AddReference("core:HSE.Core.dll"); 
     __.Host.Processor.AddReference("pkg:HSE.Package.Standard/HSE.Package.Standard.dll"); 
 }
 
#compile (build=ctor)  {   
  using HSE.Package.Standard.Processing.Directives;
     __.Host.Processor.RegisterDirective(new PrintDirective( __.Host.Processor,"#", new string[] { "print" }));  
     __.Host.Processor.RegisterDirective(new ProjectDirective( __.Host.Processor,"#", new string[] { "project" }));
     __.Host.Processor.RegisterDirective(new DefineDirective( __.Host.Processor, "#",new string[] { "define" }));
     __.Host.Processor.RegisterDirective(new UndefineDirective( __.Host.Processor, "#",new string[] { "undef" }));
     __.Host.Processor.RegisterDirective(new RedefineDirective( __.Host.Processor, "#",new string[] { "redef" })); 
     __.Host.Processor.RegisterDirective(new ConditionalDirective( __.Host.Processor , "#",new string[] { "if", "ifdef", "ifndef", "else", "elif", "endif" })); 
     __.Host.Processor.RegisterDirective(new RegionDirective( __.Host.Processor,"#", new string[] { "region", "endregion" })); 
     __.Host.Processor.RegisterDirective(new HostArgDirective( __.Host.Processor,"#", new string[] { "host" }));
 }


 
#define R __.Host.Processor.ResolvePath
 
/*

This is here purely ts here for research purpouses. 
Its best to use declarative version (stdd.hs), because :

In comparison **two different initialization models** for the same capability (directive availability), implemented at **different layers of your pipeline**. They *do* result in the same observable behavior, but they are **not equivalent in responsibility, timing, or architectural intent**.

Below is a precise analysis, not stylistic opinion.

---

## 1. What Each Block *Actually* Is

### A. First Block — *Declarative, Preprocessor-Only Header*

```text
#reference core:HSE.Core.dll
#register HSE.Core.Processing.Directives.PrintDirective(#print)
#register HSE.Core.Processing.Directives.ProjectDirective(#project)
...
```

**Characteristics**

* Purely **declarative**
* Executed entirely by the **preprocessor / directive engine**
* No imperative code
* No direct compiler involvement
* Order-independent (mostly)
* Safe to parse without Roslyn / CLR execution

**What it does conceptually**

* Declares *dependencies*
* Declares *directive bindings*
* Describes a **capability surface**

This is a **header**, not initialization logic.

---

### B. Second Block — *Imperative, Compiler-Mediated Bootstrap*

```csharp
#compile (build=ctor) {
    __.Host.Processor.AddReference("core:HSE.Core.dll");
}
```

```csharp
#compile (build=ctor) {
    using HSE.Core.Processing.Directives;
    __.Host.Processor.RegisterDirective(new PrintDirective(...));
    ...
}
```

**Characteristics**

* Imperative C# code
* Executed by the **compiler**
* Requires:

  * CLR execution
  * Roslyn compilation
  * Host availability
* Order-dependent
* Can do arbitrary logic

**What it does conceptually**

* Executes a **bootstrap program**
* Mutates host state
* Performs registration procedurally

This is **initialization code**, not a header.

---

## 2. Why They Are Not the Same (Even If Results Match)

| Dimension             | Preprocessor Header | Compiler Bootstrap |
| --------------------- | ------------------- | ------------------ |
| Layer                 | Preprocess          | Compile            |
| Determinism           | High                | Medium             |
| Side effects          | Restricted          | Arbitrary          |
| Security              | Safe                | Unsafe by default  |
| Tooling introspection | Easy                | Hard               |
| Static analysis       | Trivial             | Non-trivial        |
| Cross-language        | Possible            | No                 |
| Reusability           | High                | Low                |
| Cacheability          | High                | Low                |

The first **describes** behavior.
The second **executes** behavior.

---

## 3. When Each Is the Correct Choice

### Use the *Preprocessor Header* when:

* Defining **standard directive sets**
* Shipping **framework-level defaults**
* You want:

  * Deterministic startup
  * Declarative configuration
  * No arbitrary code execution
* You want tooling to:

  * List directives
  * Validate availability
  * Detect conflicts
* You want the file to behave like:

  * C/C++ headers
  * Zig `std`
  * Rust prelude

This should be your **default and recommended path**.

---

### Use the *Compiler Bootstrap* when:

* Registration logic depends on:

  * Runtime conditions
  * Host state
  * Environment inspection
* You need:

  * Conditional registration
  * Dynamic tokens
  * Computed aliases
* You are implementing:

  * Plugins
  * Experimental features
  * Host extensions
* You explicitly accept:

  * Non-determinism
  * Side effects

This should be **opt-in and advanced**.

---

## 4. What You Should Call Them (This Matters)

### First Block (Preprocessor)

**Recommended names**

* `directive-header`
* `directive-manifest`
* `prelude`
* `directive-spec`
* `hse.prelude`

Most correct term architecturally:

> **Directive Manifest**

It describes *what exists*, not *how to construct it*.

---

### Second Block (Compiler)

**Recommended names**

* `bootstrap`
* `initializer`
* `host-extension`
* `compiler-extension`
* `runtime-bootstrap`

Most correct term:

> **Compiler Bootstrap**

---

## 5. Strong Architectural Recommendation

You should **treat these as two distinct concepts**, not interchangeable mechanisms.

### Rule of thumb

> **If it can be expressed as `#register`, it must NOT require `#compile`.**

Violations of this rule indicate architectural leakage.

---

## 6. Suggested Final Model

* **Directive Manifest** (preprocessor, declarative)

  * Default
  * Safe
  * Cacheable
* **Compiler Bootstrap** (imperative)

  * Explicit
  * Advanced
  * Potentially unsafe
  * Requires trust

This mirrors:

* Headers vs source
* Manifest vs installer
* AST vs runtime

---

If you want, next I can:

* Formalize `#register` semantics (ordering, conflicts, scopes)
* Define a **module / prelude system**
* Design a secure sandbox for `#compile`
* Propose how tooling should surface both

This is a solid design; you are already very close to a clean separation of concerns.

*/
