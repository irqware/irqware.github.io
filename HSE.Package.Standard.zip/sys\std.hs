  
#reference pkg:HSE.Package.Standard/HSE.Package.Standard.dll
#register HSE.Package.Standard.Processing.Directives.PrintDirective(#,print)  
#register HSE.Package.Standard.Processing.Directives.DefineDirective(#,define)
#register HSE.Package.Standard.Processing.Directives.UndefineDirective(#,undef)
#register HSE.Package.Standard.Processing.Directives.RedefineDirective(#,redef)
#register HSE.Package.Standard.Processing.Directives.ConditionalDirective(#,if,ifdef,ifndef,else,elif,endif)
#register HSE.Package.Standard.Processing.Directives.RegionDirective(#,region,endregion)

 


#define R __.Host.Processor.ResolvePath
#define PrintLn __.WriteLine
#define Print __.Write
